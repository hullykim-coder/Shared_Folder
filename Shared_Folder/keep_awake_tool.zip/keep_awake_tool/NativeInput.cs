using System.Runtime.InteropServices;

namespace KeepAwakeTool;

/// <summary>Simulates key presses via SendInput so the OS sees real input and resets the idle/lock timer.</summary>
internal static class NativeInput
{
    private const ushort VK_LWIN = 0x5B;
    private const ushort VK_ESCAPE = 0x1B;
    private const uint INPUT_KEYBOARD = 1;
    private const uint KEYEVENTF_KEYUP = 0x0002;

    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public uint type;
        public KEYBDINPUT ki;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    private static INPUT KeyInput(ushort vk, bool keyUp) => new()
    {
        type = INPUT_KEYBOARD,
        ki = new KEYBDINPUT
        {
            wVk = vk,
            wScan = 0,
            dwFlags = keyUp ? KEYEVENTF_KEYUP : 0,
            time = 0,
            dwExtraInfo = IntPtr.Zero,
        },
    };

    /// <summary>
    /// Taps the Windows key and immediately taps Escape to close the Start menu it
    /// would otherwise open, so the only visible effect is the idle timer resetting.
    /// </summary>
    public static void TapWindowsKey()
    {
        SendInput(2, new[] { KeyInput(VK_LWIN, false), KeyInput(VK_LWIN, true) }, Marshal.SizeOf<INPUT>());
        SendInput(2, new[] { KeyInput(VK_ESCAPE, false), KeyInput(VK_ESCAPE, true) }, Marshal.SizeOf<INPUT>());
    }
}
