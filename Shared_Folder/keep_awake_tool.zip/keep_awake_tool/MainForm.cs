namespace KeepAwakeTool;

public class MainForm : Form
{
    private readonly System.Windows.Forms.Timer _timer = new();
    private readonly NumericUpDown _intervalMinutes;
    private readonly CheckBox _enabledCheckBox;
    private readonly Label _statusLabel;
    private readonly NotifyIcon _trayIcon;
    private int _secondsUntilNextTap;

    public MainForm()
    {
        Text = "Keep Awake Tool";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(280, 140);

        var intervalLabel = new Label { Text = "주기 (분):", Location = new Point(16, 20), AutoSize = true };
        _intervalMinutes = new NumericUpDown
        {
            Location = new Point(100, 16),
            Width = 80,
            Minimum = 1,
            Maximum = 120,
            Value = 10,
        };
        _intervalMinutes.ValueChanged += (_, _) => ResetCountdown();

        _enabledCheckBox = new CheckBox
        {
            Text = "기능 켜기",
            Location = new Point(16, 56),
            AutoSize = true,
            Checked = true,
        };
        _enabledCheckBox.CheckedChanged += (_, _) => OnEnabledChanged();

        _statusLabel = new Label
        {
            Location = new Point(16, 92),
            AutoSize = false,
            Width = 248,
            Height = 32,
            Text = "대기 중...",
        };

        Controls.Add(intervalLabel);
        Controls.Add(_intervalMinutes);
        Controls.Add(_enabledCheckBox);
        Controls.Add(_statusLabel);

        _timer.Interval = 1000;
        _timer.Tick += Timer_Tick;

        _trayIcon = new NotifyIcon
        {
            Icon = SystemIcons.Application,
            Text = "Keep Awake Tool",
            Visible = true,
            ContextMenuStrip = BuildTrayMenu(),
        };
        _trayIcon.DoubleClick += (_, _) => ShowFromTray();

        ResetCountdown();
        _timer.Start();
    }

    private ContextMenuStrip BuildTrayMenu()
    {
        var menu = new ContextMenuStrip();
        var toggleItem = new ToolStripMenuItem("켜기/끄기", null, (_, _) => _enabledCheckBox.Checked = !_enabledCheckBox.Checked);
        var showItem = new ToolStripMenuItem("열기", null, (_, _) => ShowFromTray());
        var exitItem = new ToolStripMenuItem("종료", null, (_, _) => ExitApplication());
        menu.Items.Add(showItem);
        menu.Items.Add(toggleItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(exitItem);
        return menu;
    }

    private void ShowFromTray()
    {
        Show();
        WindowState = FormWindowState.Normal;
        Activate();
    }

    private void ExitApplication()
    {
        _trayIcon.Visible = false;
        _trayIcon.Dispose();
        Application.Exit();
    }

    private void OnEnabledChanged()
    {
        _intervalMinutes.Enabled = _enabledCheckBox.Checked;
        ResetCountdown();
        UpdateStatusLabel();
    }

    private void ResetCountdown()
    {
        _secondsUntilNextTap = (int)_intervalMinutes.Value * 60;
        UpdateStatusLabel();
    }

    private void Timer_Tick(object? sender, EventArgs e)
    {
        if (!_enabledCheckBox.Checked)
        {
            UpdateStatusLabel();
            return;
        }

        _secondsUntilNextTap--;
        if (_secondsUntilNextTap <= 0)
        {
            NativeInput.TapWindowsKey();
            ResetCountdown();
        }

        UpdateStatusLabel();
    }

    private void UpdateStatusLabel()
    {
        if (!_enabledCheckBox.Checked)
        {
            _statusLabel.Text = "꺼짐";
            _trayIcon.Text = "Keep Awake Tool (꺼짐)";
            return;
        }

        var minutes = _secondsUntilNextTap / 60;
        var seconds = _secondsUntilNextTap % 60;
        _statusLabel.Text = $"다음 입력까지: {minutes:D2}:{seconds:D2}";
        _trayIcon.Text = $"Keep Awake Tool ({minutes:D2}:{seconds:D2})";
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        // Closing the window minimizes to tray instead of exiting; use the
        // tray menu's "종료" to actually quit.
        if (e.CloseReason == CloseReason.UserClosing)
        {
            e.Cancel = true;
            Hide();
            return;
        }

        base.OnFormClosing(e);
    }
}
