# Keep Awake Tool

화면 잠금/절전을 막기 위해 일정 주기로 Windows 키를 눌렀다 떼는 Windows 트레이 유틸리티입니다.
(Win 키 단독 입력은 시작 메뉴를 열기 때문에, 곧바로 Esc를 보내 닫습니다 — 화면에는 거의 표시되지 않습니다.)

## 기능

- 주기 설정 (기본 10분, 1~120분)
- 켜기/끄기 체크박스
- 창을 닫으면 트레이로 최소화 (트레이 메뉴의 "종료"로만 완전히 종료)
- 트레이 아이콘 더블클릭으로 창 다시 열기

## 빌드 / 실행

.NET 8 SDK가 필요합니다 (https://dotnet.microsoft.com/download 에서 "SDK" 설치, 런타임만으로는 빌드 불가).

```powershell
dotnet run
```

또는 단일 실행 파일(.exe)로 배포:

```powershell
dotnet publish -c Release -r win-x64 --self-contained false
```
